package com.cg.springco;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {
	public static void main(String[] args) {
		
		ConfigurableApplicationContext context=new ClassPathXmlApplicationContext("spring.xml");
		Employee e1=context.getBean(Employee.class);
		System.out.println(e1);
	}
}
