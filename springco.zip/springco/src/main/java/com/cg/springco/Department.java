package com.cg.springco;

public class Department {
int deptno;
String desig;
public Department() {
	// TODO Auto-generated constructor stub
}
public Department(int deptno, String desig) {
	super();
	this.deptno = deptno;
	this.desig = desig;
}
public int getDeptno() {
	return deptno;
}
public void setDeptno(int deptno) {
	this.deptno = deptno;
}
public String getDesig() {
	return desig;
}
public void setDesig(String desig) {
	this.desig = desig;
}
@Override
public String toString() {
	return "Department [deptno=" + deptno + ", desig=" + desig + "]";
}

}
