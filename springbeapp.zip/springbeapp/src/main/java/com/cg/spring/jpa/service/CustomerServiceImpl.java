package com.cg.spring.jpa.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.spring.jpa.Customer;
import com.cg.spring.jpa.repository.ICustomerRepo;
@Component
public class CustomerServiceImpl implements ICustomerService{
	@Autowired
ICustomerRepo repo;
	List<Customer> list=null;
	@Override
	public List<Customer> getAll() {
		 list=new ArrayList();
		repo.findAll().forEach(list::add);
		return list;
	}
public void add(Customer c) {
		
		repo.save(c);
		
	}
@Override
public void delete(int id) {
	List<Customer> list=getAll();
	for(Customer c:list)
	{
		if(c.getId()==id)
		{
			repo.delete(c);
		}
	}

}
@Override
public void update(Customer c) {
             Customer k=repo.findOne(c.getId());	
             k.setCity(c.getCity());
             k.setMailid(c.getMailid());
             repo.save(k);
}
}
