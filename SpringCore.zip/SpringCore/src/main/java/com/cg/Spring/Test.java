package com.cg.Spring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class Test {
public static void main(String[] args) {
//	Resource resource=new ClassPathResource("applicationContext.xml");
//	BeanFactory factory=new XmlBeanFactory(resource);
	ApplicationContext context=new ClassPathXmlApplicationContext("Spring.xml");

	Student s=(Student)context.getBean("studentbean");
	//Student s=context.getBean(Student.class);
	//s.setName("Manasa");
	System.out.println(s);

}
}
