package com.cg.example.demo.service;


import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.example.demo.beans.Product;


@Service
public interface IProductService {
	List<Product> getAllProducts();
	Product searchById(int id);
	//Product add(String name,double price);
	List<Product> add(Product p);
	void update(int id,String name, double price);
}
