package com.cg.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;


import com.cg.example.demo.beans.Product;
import com.cg.example.demo.service.IProductService;



@RestController
@ComponentScan(basePackages="com.cg.example")
public class ProductController {
	
	@Autowired
	IProductService service;

	@RequestMapping("/getall")
	public List<Product> getAllProducts(){
		return service.getAllProducts();

	}
	
	@RequestMapping("/get/{id}")
	public Product getProducts(@PathVariable("id") int id){
		return service.searchById(id);

	}
	/*@RequestMapping("/add/{name}/{price}")
	public String add(@PathVariable("name") String name,@PathVariable("price") double price) {
		service.add(name,price);
		return "product added successfully";
	}*/
	@RequestMapping("/add/{name}/{price}")
	public List<Product> add(Product p,@PathVariable("name") String name,@PathVariable("price") double price) {
		return service.add(p);
	//	return "product added successfully";
	}
	@RequestMapping("/update/{id}/{name}/{price}")
	public String update(@PathVariable("id") int id,@PathVariable("name") String name,@PathVariable("price") double price) {
		 service.update(id,name,price);
		return "product updated successfully";
	}
}
