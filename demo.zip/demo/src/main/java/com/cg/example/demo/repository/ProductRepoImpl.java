package com.cg.example.demo.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.cg.example.demo.beans.Product;

@Component
public class ProductRepoImpl implements IProductRepo {
	List<Product> list=new ArrayList();
	public List<Product> getAllProducts() {
		Product p1=new Product();
		p1.setId(list.size()+1);
		p1.setName("iphone 6s");
		p1.setPrice(9800);
		list.add(p1);
		Product p2=new Product();
		p2.setId(list.size()+1);
		p2.setName("Samsung Galaxy S4");
		p2.setPrice(8900);
		list.add(p2);
		return list;
	}
	public Product searchById(int id) {
		for(Product p:list)
		{
			if(p.getId()==id) {
				return p;
			}
		}
		System.out.println("Records are not found");
		return null;
	}
	/*@Override
	public Product add(String name,double price) {
		// TODO Auto-generated method stub
		Product p2=new Product();
		p2.setId(list.size()+1);
		p2.setName(name);
		p2.setPrice(price);
		list.add(p2);
		return p2;
	}*/
	@Override
	public List<Product> add(Product p) {
		// TODO Auto-generated method stub
		p.setId(list.size()+1);
		list.add(p);
		return list;
	}
	@Override
	public void update(int id,String name, double price) {
		for(Product p:list)
		{
			if(p.getId()==id) {
			p.setName(name);
			p.setPrice(price);
			}
		}
		
	}
}
