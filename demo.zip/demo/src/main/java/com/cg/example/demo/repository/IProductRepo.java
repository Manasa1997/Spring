package com.cg.example.demo.repository;


import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.example.demo.beans.Product;

@Repository
public interface IProductRepo {
List<Product> getAllProducts();
//Product add(String name,double price);
List<Product> add(Product p);
Product searchById(int id);
void update(int id,String name, double price);

}

