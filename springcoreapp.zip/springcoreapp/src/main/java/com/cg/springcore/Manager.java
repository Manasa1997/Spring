package com.cg.springcore;

public class Manager {
	private int deptno;
	private String projectname;
	private String projectcode;
/*	public Manager(int deptno, String projectname, String projectcode) {
		super();
		this.deptno = deptno;
		this.projectname = projectname;
		this.projectcode = projectcode;
	}*/
	@Override
	public String toString() {
		return "Manager [deptno=" + deptno + ", projectname=" + projectname + ", projectcode=" + projectcode + "]";
	}
	public int getDeptno() {
		return deptno;
	}
	public void setDeptno(int deptno) {
		this.deptno = deptno;
	}
	public String getProjectname() {
		return projectname;
	}
	public void setProjectname(String projectname) {
		this.projectname = projectname;
	}
	public String getProjectcode() {
		return projectcode;
	}
	public void setProjectcode(String projectcode) {
		this.projectcode = projectcode;
	}
}
