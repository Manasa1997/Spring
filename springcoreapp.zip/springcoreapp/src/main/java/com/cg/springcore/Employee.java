package com.cg.springcore;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class Employee implements InitializingBean,DisposableBean{
private int id;
private String name;
private double salary;
public Employee() {
	// TODO Auto-generated constructor stub
}
/*public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public double getSalary() {
	return salary;
}
public void setSalary(double salary) {
	this.salary = salary;
}*/
//We don't need getters and setters for constructor type
@Override
public String toString() {
	return "Employee [id=" + id + ", name=" + name + ", salary=" + salary + "]";
}
public Employee(int id, String name, double salary) {
	super();
	this.id = id;
	this.name = name;
	this.salary = salary;
}

//First way of doing
public void afterPropertiesSet() throws Exception{
//	System.out.println("init method for employee bean");
}
public void destroy() throws Exception {
	// TODO Auto-generated method stub
	//System.out.println("DESTROY method for employee bean");
}


//Second way of doing
@PreDestroy
public void preDestroy() {
	System.out.println("pre destroy method for employee bean");
}
@PostConstruct
public void postConstruct() {
	System.out.println("post construct or init method for emp bean");
}



//Third way of doing
public void init() {
	System.out.println("init method calling from xml");
}
public void destroyBean() {
	System.out.println("destroy method calling from xml");
}
}