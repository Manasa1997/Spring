package com.cg.springcore;

//import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestEmployee {

	public static void main(String[] args) {
	//ApplicationContext context=new ClassPathXmlApplicationContext("spring.xml");
/*	Employee e1=new Employee;
		e1.setName("Manasa");
		System.out.println(e1);*/
	//Employee e1=context.getBean(Employee.class);or the other way is to inject is:
		ConfigurableApplicationContext context=new ClassPathXmlApplicationContext("spring.xml");
	Employee e1=(Employee)context.getBean("emp");
	System.out.println(e1);
	context.close();
	/*e1.setId(1);
	e1.setName("Manasa");
	e1.setSalary(100000);
	System.out.println(e1);Intialize data in xml file is done by*/
	//Manager m1=context.getBean(Manager.class);
	/*m1.setDeptno(1);
	m1.setProjectname("Sprint");
	m1.setProjectcode("108");*/
	//System.out.println(m1);
	}

}
