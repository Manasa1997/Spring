package com.cg.spring.mvc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.spring.mvc.bean.Product;
import com.cg.spring.mvc.repository.IProductRepo;

@Component

public class ProductServiceImpl implements IProductService {
@Autowired
	IProductRepo repo;
	public List<Product> getAllProducts() {
	
		return repo.getAllProducts();
	}
	public void add(Product p) {
		// TODO Auto-generated method stub
repo.add(p);		
	}
	public Product searchById(int id) {
		// TODO Auto-generated method stub
		return repo.searchById(id);
	}
	public Product deleteById(int id) {
		// TODO Auto-generated method stub
		return repo.deleteById(id);
	}
	public Product updateById(int id) {
		// TODO Auto-generated method stub
		return repo.deleteById(id);
	}


}
