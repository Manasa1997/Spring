package com.cg.spring.mvc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.spring.mvc.bean.Product;
import com.cg.spring.mvc.service.IProductService;
@Controller
public class ProductController {
	@Autowired
	IProductService service;
	@RequestMapping(value="/getall",method=RequestMethod.GET)
	public ModelAndView getAllProducts(){
		ModelAndView mv=new ModelAndView("showall");
	mv.addObject("products",service.getAllProducts());
	return mv;
	}
	@RequestMapping(value="/addp",method=RequestMethod.GET)
	public ModelAndView addproduct(){
		ModelAndView mv=new ModelAndView("add");
	mv.addObject("command",new Product());
	return mv;
	
}
	@RequestMapping(value="/addproduct",method=RequestMethod.POST)
	public String add(Product p) {
		service.add(p);
		return "redirect:/getall";
	}
	@RequestMapping(value="/search",method=RequestMethod.GET)
	public ModelAndView searchproduct(@RequestParam("id")int id){
		ModelAndView mv=new ModelAndView("showone");
	mv.addObject("product",service.searchById(id));
	return mv;
	}
	@RequestMapping(value="/delete1",method=RequestMethod.GET)
	public ModelAndView deleteproduct(@RequestParam("id")int id){
		ModelAndView mv=new ModelAndView("delete");
	mv.addObject("product",service.deleteById(id));
	return mv;
	}
	@RequestMapping(value="/upd",method=RequestMethod.GET)
	public ModelAndView updateproduct(@RequestParam("id")int id){
		ModelAndView mv=new ModelAndView("update");
	mv.addObject("product",service.updateById(id));
	return mv;
	}
	@RequestMapping(value="/addproduct",method=RequestMethod.POST)
	public String update(Product p) {
		//service.update(p);
		return "redirect:/getall";
}
}
