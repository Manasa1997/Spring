package com.cg.spring.mvc.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.cg.spring.mvc.bean.Product;
@Component
public class ProductRepoImpl implements IProductRepo {
	List<Product>  list=new ArrayList();
	public List<Product> getAllProducts() {
		
		return list;
	}
	public void add(Product p) {
		Product p1=new Product();
		p1.setId(list.size()+1);
		p1.setName("iphone 6s");
		p1.setPrice(9800);
		list.add(p1);
		Product p2=new Product();
		p2.setId(list.size()+1);
		p2.setName("Samsung Galaxy S4");
		p2.setPrice(8900);
		list.add(p2);
		p.setId(list.size()+1);
		list.add(p);
	}
	public Product searchById(int id) {
		for(Product p:list)
		{
			if(p.getId()==id) {
				return p;
			}
		}
		System.out.println("Records are not found");
		return null;
	}
	public Product deleteById(int id) {
		for(Product p:list)
		{
			if(p.getId()==id) {
				list.remove(p);
				System.out.println("deleted");
			}
		}
		return null;
	}
	public Product updateById(int id) {
		for(Product p:list)
		{
			if(p.getId()==id) {
				//list.;
				System.out.println("deleted");
			}
		}
		return null;
	}
	

}
