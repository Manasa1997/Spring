package com.cg.spring.mvc.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class FrontController {

	
	@RequestMapping(value="/getall",method=RequestMethod.GET)
	public ModelAndView getAllCustomers() {
		ModelAndView mv=new ModelAndView("showall");
		RestTemplate template=new RestTemplate();
		List<Customer> list=template.getForObject("http://localhost:9395/getall", ArrayList.class);
		mv.addObject("customers",list);
		return mv;
	}
	@RequestMapping(value="/add",method=RequestMethod.GET)
	public ModelAndView add() {
		ModelAndView mv=new ModelAndView("add_customer");
		mv.addObject("command",new Customer());
		return mv;
	}
	@RequestMapping(value="/addc",method=RequestMethod.POST)
	public String addCustomer(Customer c) {
		RestTemplate temp=new RestTemplate();
		temp.postForObject("http://localhost:9395/add",c,String.class);
		return "redirect:/getall";
	}
	@RequestMapping(value="/delete",method=RequestMethod.GET)
	public String deleteCustomer(@RequestParam(value="id")int id) {
		RestTemplate temp=new RestTemplate();
		temp.postForObject("http://localhost:9395/delete",id,String.class);
		return "redirect:/getall";
	}
	
	@RequestMapping(value="/update1",method=RequestMethod.GET)
	public ModelAndView updateCustomer(@RequestParam(value="id")int id ,@RequestParam(value="name") String name) {
		ModelAndView mv=new ModelAndView("update");
		mv.addObject("id",new Integer(id));
		mv.addObject("name",new String(name));
		mv.addObject("command",new Customer());
		return mv;
	}
	@RequestMapping(value="/update2",method=RequestMethod.POST)
	public String updateCustomer(Customer c) {
		RestTemplate temp=new RestTemplate();
		temp.postForObject("http://localhost:9395/update1",c,String.class);
		return "redirect:/getall";
	}
	
	
	
	
}
